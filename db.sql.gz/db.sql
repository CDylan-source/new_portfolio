--
-- PostgreSQL database dump
--

SET statement_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SET check_function_bodies = false;
SET client_min_messages = warning;

SET search_path = public, pg_catalog;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: portfolio_joint; Type: TABLE; Schema: public; Owner: ljcu6936; Tablespace: 
--

CREATE TABLE portfolio_joint (
    id integer NOT NULL,
    idprojet integer NOT NULL,
    idtag integer NOT NULL
);


ALTER TABLE public.portfolio_joint OWNER TO ljcu6936;

--
-- Name: portfolio_joint_id_seq; Type: SEQUENCE; Schema: public; Owner: ljcu6936
--

CREATE SEQUENCE portfolio_joint_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.portfolio_joint_id_seq OWNER TO ljcu6936;

--
-- Name: portfolio_joint_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ljcu6936
--

ALTER SEQUENCE portfolio_joint_id_seq OWNED BY portfolio_joint.id;


--
-- Name: portfolio_projets; Type: TABLE; Schema: public; Owner: ljcu6936; Tablespace: 
--

CREATE TABLE portfolio_projets (
    idprojet integer NOT NULL,
    titre character varying NOT NULL,
    lien character varying,
    short character varying NOT NULL,
    description character varying NOT NULL,
    image character varying NOT NULL
);


ALTER TABLE public.portfolio_projets OWNER TO ljcu6936;

--
-- Name: portfolio_projets_idprojet_seq; Type: SEQUENCE; Schema: public; Owner: ljcu6936
--

CREATE SEQUENCE portfolio_projets_idprojet_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.portfolio_projets_idprojet_seq OWNER TO ljcu6936;

--
-- Name: portfolio_projets_idprojet_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ljcu6936
--

ALTER SEQUENCE portfolio_projets_idprojet_seq OWNED BY portfolio_projets.idprojet;


--
-- Name: portfolio_tags; Type: TABLE; Schema: public; Owner: ljcu6936; Tablespace: 
--

CREATE TABLE portfolio_tags (
    idtag integer NOT NULL,
    tag character varying NOT NULL
);


ALTER TABLE public.portfolio_tags OWNER TO ljcu6936;

--
-- Name: portfolio_tags_idtag_seq; Type: SEQUENCE; Schema: public; Owner: ljcu6936
--

CREATE SEQUENCE portfolio_tags_idtag_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.portfolio_tags_idtag_seq OWNER TO ljcu6936;

--
-- Name: portfolio_tags_idtag_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ljcu6936
--

ALTER SEQUENCE portfolio_tags_idtag_seq OWNED BY portfolio_tags.idtag;


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: ljcu6936
--

ALTER TABLE ONLY portfolio_joint ALTER COLUMN id SET DEFAULT nextval('portfolio_joint_id_seq'::regclass);


--
-- Name: idprojet; Type: DEFAULT; Schema: public; Owner: ljcu6936
--

ALTER TABLE ONLY portfolio_projets ALTER COLUMN idprojet SET DEFAULT nextval('portfolio_projets_idprojet_seq'::regclass);


--
-- Name: idtag; Type: DEFAULT; Schema: public; Owner: ljcu6936
--

ALTER TABLE ONLY portfolio_tags ALTER COLUMN idtag SET DEFAULT nextval('portfolio_tags_idtag_seq'::regclass);


--
-- Data for Name: portfolio_joint; Type: TABLE DATA; Schema: public; Owner: ljcu6936
--

COPY portfolio_joint (id, idprojet, idtag) FROM stdin;
1	1	1
2	1	2
3	1	4
4	1	5
\.


--
-- Name: portfolio_joint_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ljcu6936
--

SELECT pg_catalog.setval('portfolio_joint_id_seq', 4, true);


--
-- Data for Name: portfolio_projets; Type: TABLE DATA; Schema: public; Owner: ljcu6936
--

COPY portfolio_projets (idprojet, titre, lien, short, description, image) FROM stdin;
1	Fiday Gestion	http://www.fidaygestion.fr/	Site réalisé sous Wordpress lors de mon stage de fin de formation	J'ai pu participer à l'élaboration de ce site lors de mon stage de fin de formation, intégralement sous Wordpress. C'était un projet enrichissant par la proximité avec mes "clients". Un deuxième stagiaire sera venu par la suite afin de réaliser les nouvelles demandes du PDG de l'entreprise (comme réaliser des articles)	https://drive.google.com/uc?export=view&id=1V-g0J2IsVKc40iJUP2eWW1rQHsueKr17
\.


--
-- Name: portfolio_projets_idprojet_seq; Type: SEQUENCE SET; Schema: public; Owner: ljcu6936
--

SELECT pg_catalog.setval('portfolio_projets_idprojet_seq', 1, true);


--
-- Data for Name: portfolio_tags; Type: TABLE DATA; Schema: public; Owner: ljcu6936
--

COPY portfolio_tags (idtag, tag) FROM stdin;
1	Wordpress
2	PHP
3	Reactjs
4	HTML5
5	CSS3
6	Js
7	Bootstrap
\.


--
-- Name: portfolio_tags_idtag_seq; Type: SEQUENCE SET; Schema: public; Owner: ljcu6936
--

SELECT pg_catalog.setval('portfolio_tags_idtag_seq', 7, true);


--
-- Name: portfolio_joint_pkey; Type: CONSTRAINT; Schema: public; Owner: ljcu6936; Tablespace: 
--

ALTER TABLE ONLY portfolio_joint
    ADD CONSTRAINT portfolio_joint_pkey PRIMARY KEY (id);


--
-- Name: portfolio_projets_pkey; Type: CONSTRAINT; Schema: public; Owner: ljcu6936; Tablespace: 
--

ALTER TABLE ONLY portfolio_projets
    ADD CONSTRAINT portfolio_projets_pkey PRIMARY KEY (idprojet);


--
-- Name: portfolio_tags_pkey; Type: CONSTRAINT; Schema: public; Owner: ljcu6936; Tablespace: 
--

ALTER TABLE ONLY portfolio_tags
    ADD CONSTRAINT portfolio_tags_pkey PRIMARY KEY (idtag);


--
-- Name: portfolio_projets_idprojet_fkey; Type: FK CONSTRAINT; Schema: public; Owner: ljcu6936
--

ALTER TABLE ONLY portfolio_joint
    ADD CONSTRAINT portfolio_projets_idprojet_fkey FOREIGN KEY (idprojet) REFERENCES portfolio_projets(idprojet) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: portfolio_tags_idtag_fkey; Type: FK CONSTRAINT; Schema: public; Owner: ljcu6936
--

ALTER TABLE ONLY portfolio_joint
    ADD CONSTRAINT portfolio_tags_idtag_fkey FOREIGN KEY (idtag) REFERENCES portfolio_tags(idtag) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: public; Type: ACL; Schema: -; Owner: postgres
--

REVOKE ALL ON SCHEMA public FROM PUBLIC;
REVOKE ALL ON SCHEMA public FROM postgres;
GRANT ALL ON SCHEMA public TO postgres;
GRANT ALL ON SCHEMA public TO PUBLIC;


--
-- Name: portfolio_joint; Type: ACL; Schema: public; Owner: ljcu6936
--

REVOKE ALL ON TABLE portfolio_joint FROM PUBLIC;
REVOKE ALL ON TABLE portfolio_joint FROM ljcu6936;
GRANT ALL ON TABLE portfolio_joint TO ljcu6936;
GRANT ALL ON TABLE portfolio_joint TO ljcu6936_portfolio;


--
-- Name: portfolio_projets; Type: ACL; Schema: public; Owner: ljcu6936
--

REVOKE ALL ON TABLE portfolio_projets FROM PUBLIC;
REVOKE ALL ON TABLE portfolio_projets FROM ljcu6936;
GRANT ALL ON TABLE portfolio_projets TO ljcu6936;
GRANT ALL ON TABLE portfolio_projets TO ljcu6936_portfolio;


--
-- Name: portfolio_tags; Type: ACL; Schema: public; Owner: ljcu6936
--

REVOKE ALL ON TABLE portfolio_tags FROM PUBLIC;
REVOKE ALL ON TABLE portfolio_tags FROM ljcu6936;
GRANT ALL ON TABLE portfolio_tags TO ljcu6936;
GRANT ALL ON TABLE portfolio_tags TO ljcu6936_portfolio;


--
-- PostgreSQL database dump complete
--

